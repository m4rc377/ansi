# Ubuntu Provisioning Full

Otomatisasi instalasi dan konfigurasi Ubuntu desktop menggunakan Ansible.

## Struktur

Role: `config`, `app`, `db`, `media`  
Fitur:
- Jalankan role sesuai urutan
- Simpan status `.installed_state`
- GUI launcher via Zenity
- Mendukung file `.deb`, shell script, dan apt
- `validate_and_run.yml` untuk validasi dan eksekusi modular

## Penggunaan

```bash
ansible-playbook playbook.yml
```

GUI:
```bash
bin/gui-launcher.sh
```

## Catatan

- GUI saat ini menggunakan `zenity`, belum ada fallback ke `whiptail`
- `.installed_state.json` disimpan di `/var/tmp`
