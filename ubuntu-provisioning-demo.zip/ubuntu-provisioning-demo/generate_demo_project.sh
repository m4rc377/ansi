#!/bin/bash
set -e

BASE="ubuntu-provisioning-full"

FILES=(
  "playbook.yml"
  "run_role.yml"
  "README.md"
  "bin/gui-launcher.sh"
  "files/upgrade_apt.yml"
  "host_vars/localhost.yml"
  ".github/workflows/test.yml"
  "molecule/default/converge.yml"
  "molecule/default/molecule.yml"
  "molecule/default/verify.yml"
  "roles/common/tasks/main.yml"
  "roles/common/tasks/install_package.yml"
  "roles/common/tasks/install_deb_package.yml"
  "roles/common/tasks/unzip_file.yml"
  "roles/common/tasks/wrapper_shell_command.yml"
  "roles/common/tasks/install_from_shell.yml"
  "roles/common/tasks/validate_and_run.yml"
  "roles/common/tasks/reboot_after_task.yml"
  "roles/app/tasks/main.yml"
  "roles/app/tasks/ordered.yml"
  "roles/app/tasks/chrome.yml"
  "roles/app/tasks/firefox.yml"
  "roles/app/tasks/php.yml"
  "roles/app/tasks/vscode.yml"
  "roles/app/tasks/vlc.yml"
  "roles/config/tasks/main.yml"
  "roles/config/tasks/ordered.yml"
  "roles/config/tasks/timezone.yml"
  "roles/config/tasks/hostname.yml"
  "roles/db/tasks/main.yml"
  "roles/db/tasks/ordered.yml"
  "roles/db/tasks/mysql.yml"
  "roles/db/tasks/phpmyadmin.yml"
  "roles/media/tasks/main.yml"
  "roles/media/tasks/ordered.yml"
  "roles/media/tasks/vlc.yml"
)

echo "Creating project structure: $BASE"
for FILE in "${FILES[@]}"; do
  DIR="$BASE/$(dirname "$FILE")"
  mkdir -p "$DIR"
  touch "$BASE/$FILE"
done

echo "Structure created successfully at $BASE/"
